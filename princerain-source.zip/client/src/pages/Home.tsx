import { ArrowDown, ArrowUpRight, Play } from "lucide-react";
import { Link } from "wouter";
import { categories, siteImages } from "@/data/site";
import { PageFrame, SectionIntro, ArrowLink } from "@/components/site/SiteChrome";
import { CategoryFeature, CompanyIntro, EnquiryBand, GalleryMosaic, ProductRail, QualityCallout, TrustStrip } from "@/components/site/SiteBlocks";

export default function Home() {
  return (
    <PageFrame>
      <main>
        <section className="hero" style={{ backgroundImage: `url(${siteImages.hero})` }}>
          <div className="hero-overlay" />
          <div className="site-shell hero-inner">
            <div className="hero-kicker"><span className="line" />01 / Official rainwear manufacturer</div>
            <h1>Ready for<br /><em>every storm.</em></h1>
            <p>Quality rainwear crafted for protection, comfort and confidence.</p>
            <div className="hero-actions"><Link className="button button-light" href="/products">Explore our products <ArrowUpRight size={16} /></Link><Link className="text-link light" href="/about">Discover our company <ArrowUpRight size={15} /></Link></div>
            <div className="hero-bottom"><span>Raincoats / Rain suits / Jackets / Over coats</span><span className="hero-scroll"><ArrowDown size={15} /> Scroll to explore</span></div>
          </div>
          <div className="hero-corner-note"><Play size={13} fill="currentColor" /> Built for the monsoon season</div>
        </section>

        <TrustStrip />

        <CompanyIntro home />

        <section className="category-section">
          <div className="site-shell category-heading"><SectionIntro eyebrow="03 / The range" title="A considered layer for every kind of day." copy="From kids' first monsoon to the daily commute, explore the categories that make up the Prince Rainwear range." /><ArrowLink href="/products">View all products</ArrowLink></div>
          <div className="category-list site-shell">{categories.map((item, index) => <CategoryFeature item={item} index={index} key={item.key} />)}</div>
        </section>

        <section className="featured-section">
          <div className="site-shell featured-heading"><SectionIntro eyebrow="04 / Featured products" title="A closer look at the range." copy="Selected styles from the official Prince Rainwear catalogue. Product images and names are preserved from the existing company website." /><span className="section-count">01 — 07</span></div>
          <div className="site-shell"><ProductRail /></div>
          <div className="site-shell section-tail"><ArrowLink href="/products">Explore the full catalogue</ArrowLink><span>Product imagery sourced from official Prince Rainwear pages.</span></div>
        </section>

        <section className="dark-story">
          <div className="site-shell dark-story-grid"><div><span className="eyebrow light-eyebrow">05 / Why Prince Rainwear</span><h2>Made with<br /><em>purpose.</em></h2></div><div className="dark-story-copy"><p>Ethical business policies, transparent dealings, cost-effective solutions and prompt deliveries have made Prince Rainwear a trusted choice for a wide clientele.</p><div className="dark-facts"><span><strong>Since</strong>2005</span><span><strong>Based in</strong>Mumbai</span><span><strong>For</strong>All India</span></div><Link className="text-link light" href="/manufacturing">See how we work <ArrowUpRight size={15} /></Link></div></div>
        </section>

        <QualityCallout />

        <section className="gallery-section"><div className="site-shell gallery-heading"><SectionIntro eyebrow="07 / Field notes" title="Inside the season." copy="A visual look at the people, products and process behind the range." /><ArrowLink href="/gallery">Open the gallery</ArrowLink></div><div className="site-shell"><GalleryMosaic /></div></section>

        <EnquiryBand />
      </main>
    </PageFrame>
  );
}
