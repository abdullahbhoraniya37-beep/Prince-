export const siteImages = {
  logo: "https://princerainwear.com/wp-content/uploads/2021/03/Prince-Logo-1.png",
  logoMark: "https://princerainwear.com/wp-content/uploads/2021/03/Prince-Logo-icon.jpg",
  hero: "https://princerainwear.com/wp-content/uploads/2022/04/Copy-of-Unnamed-Design-1.jpg",
  heroAlt: "https://princerainwear.com/wp-content/uploads/2022/04/Copy-of-Unnamed-Design-2.jpg",
  gents: "https://princerainwear.com/wp-content/uploads/2022/05/Gents-Type.png",
  ladies: "https://princerainwear.com/wp-content/uploads/2022/05/ladies-type.png",
  kids: "https://princerainwear.com/wp-content/uploads/2022/05/kids-slide.jpg",
  shipped: "https://princerainwear.com/wp-content/uploads/2022/05/shipped.png",
  quality: "https://princerainwear.com/wp-content/uploads/2022/05/quality-control.png",
  raincoat: "https://princerainwear.com/wp-content/uploads/2022/05/raincoat.png",
  girls: "https://princerainwear.com/wp-content/uploads/2022/05/girls-raincoat.jpg",
  boys: "https://princerainwear.com/wp-content/uploads/2022/05/Boys-Raincoat.jpg",
  gentsRaincoat: "https://princerainwear.com/wp-content/uploads/2022/05/Gents-Raincoat.jpg",
  ladiesRaincoat: "https://princerainwear.com/wp-content/uploads/2022/05/Ladies-Raincoat.jpg",
};

export type Category = "Girls" | "Boys" | "Gents" | "Ladies";

export type Product = {
  slug: string;
  name: string;
  category: Category;
  image: string;
  description: string;
  detail: string;
  tags: string[];
};

export const categories = [
  {
    key: "Girls" as Category,
    slug: "girls",
    kicker: "01 / Rainwear for girls",
    title: "Colour, comfort\nand coverage.",
    description: "Play-ready rainwear with the practical protection families expect from Prince Rainwear.",
    image: siteImages.girls,
    accent: "rose",
  },
  {
    key: "Boys" as Category,
    slug: "boys",
    kicker: "02 / Rainwear for boys",
    title: "Made for\nmonsoon days.",
    description: "Durable rainwear designed for movement, exploration and everyday weather protection.",
    image: siteImages.boys,
    accent: "blue",
  },
  {
    key: "Gents" as Category,
    slug: "gents",
    kicker: "03 / Rainwear for gents",
    title: "Protection with\npresence.",
    description: "Raincoats, rain suits and jackets that bring a considered finish to the everyday commute.",
    image: siteImages.gentsRaincoat,
    accent: "navy",
  },
  {
    key: "Ladies" as Category,
    slug: "ladies",
    kicker: "04 / Rainwear for ladies",
    title: "Grace in\nany weather.",
    description: "Layered silhouettes and reliable coverage for the season that asks more of your outerwear.",
    image: siteImages.ladiesRaincoat,
    accent: "silver",
  },
];

export const products: Product[] = [
  {
    slug: "anmol",
    name: "Anmol",
    category: "Boys",
    image: "https://princerainwear.com/wp-content/uploads/2022/05/Anmol-boys-raincoat-1-1-500x750.jpg",
    description: "A practical PVC raincoat for boys, built for dependable monsoon coverage.",
    detail: "Anmol is part of Prince Rainwear's boys rainwear range. It is presented as a durable PVC raincoat designed for regular use through the rainy season.",
    tags: ["Boys", "PVC rainwear", "Raincoat"],
  },
  {
    slug: "classic",
    name: "Classic",
    category: "Boys",
    image: "https://princerainwear.com/wp-content/uploads/2022/05/Classic-boys-raincoat-500x750.jpg",
    description: "A clean, everyday raincoat silhouette from the boys collection.",
    detail: "Classic brings the straightforward utility of a Prince Rainwear boys raincoat to a simple, wearable silhouette for the monsoon season.",
    tags: ["Boys", "Rainwear", "Raincoat"],
  },
  {
    slug: "classic-girls",
    name: "Classic",
    category: "Girls",
    image: "https://princerainwear.com/wp-content/uploads/2022/05/Classic-Girls-Raincoat-1-500x750.jpg",
    description: "A bright, lightweight raincoat designed for girls.",
    detail: "The girls' Classic style is part of the children's rainwear offering and is designed to make everyday protection feel easy and comfortable.",
    tags: ["Girls", "Raincoat", "Kids rainwear"],
  },
  {
    slug: "kajal-o-c",
    name: "Kajal O.C.",
    category: "Ladies",
    image: "https://princerainwear.com/wp-content/uploads/2022/06/Kajal-1-500x750.jpg",
    description: "A long coat silhouette that brings polished coverage to wet-weather days.",
    detail: "Kajal O.C. is one of the featured ladies' rainwear styles presented by Prince Rainwear, with a longer coat profile for confident coverage.",
    tags: ["Ladies", "Overcoat", "Rainwear"],
  },
  {
    slug: "marshal-o-c",
    name: "Marshal O.C.",
    category: "Gents",
    image: "https://princerainwear.com/wp-content/uploads/2022/06/Marshal-OC-500x750.jpg",
    description: "A structured overcoat style for the gents rainwear range.",
    detail: "Marshal O.C. is a featured gents style, designed as a practical long-form layer for customers looking for dependable rainwear coverage.",
    tags: ["Gents", "Overcoat", "Rainwear"],
  },
  {
    slug: "mary",
    name: "Mary",
    category: "Girls",
    image: "https://princerainwear.com/wp-content/uploads/2022/05/Mary-Girls-Raincoat-500x750.jpg",
    description: "A cheerful girls' raincoat with a friendly, easy-to-wear profile.",
    detail: "Mary is part of the girls rainwear collection, bringing a playful look to the practical needs of the monsoon season.",
    tags: ["Girls", "Raincoat", "Kids rainwear"],
  },
  {
    slug: "rider",
    name: "Rider",
    category: "Gents",
    image: "https://princerainwear.com/wp-content/uploads/2022/06/Rider-1-500x750.jpg",
    description: "A rider-focused rainwear layer made for active commutes.",
    detail: "Rider is a featured gents rainwear style for customers who need coverage that works with an active, on-the-go routine.",
    tags: ["Gents", "Rainwear", "Jacket"],
  },
  {
    slug: "star",
    name: "Star",
    category: "Ladies",
    image: "https://princerainwear.com/wp-content/uploads/2022/06/Star-500x750.jpg",
    description: "A long-form ladies' rainwear style with a refined seasonal look.",
    detail: "Star is part of the ladies collection presented on the official Prince Rainwear website, balancing a polished silhouette with everyday weather protection.",
    tags: ["Ladies", "Rainwear", "Long coat"],
  },
];

export const companyFacts = [
  { value: "2005", label: "Incorporated as a private limited company" },
  { value: "04", label: "Core rainwear categories" },
  { value: "01", label: "Mumbai head office" },
];

export const contact = {
  phone: "+91 – 22-26788486",
  mobile: "+91 – 9167535403",
  alternateMobile: "+91 – 7718019300 / 7875425468",
  email: "sales@princerainwear.com",
  address: "8, K.M.C. Compound, Near Metro Palace Hotel, Behram Baug Road, Jogeshwari (West), Mumbai – 400102. INDIA",
  factoryAddress: "Mahi Approach Road, At Mahi, (Chhapi) 385210, Taluka Vadgam, District Banaskantha, North Gujarat. INDIA",
  factoryPhone: "+91 – 8980766313",
};
