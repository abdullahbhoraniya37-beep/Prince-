import { ArrowUpRight, Check, Quote, ShieldCheck, Sparkles, Truck, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "wouter";
import { categories, companyFacts, contact, products, siteImages, type Category } from "@/data/site";
import { ArrowLink, SectionIntro } from "./SiteChrome";

export function ProductCard({ product, compact = false }: { product: (typeof products)[number]; compact?: boolean }) {
  return (
    <article className={`product-card ${compact ? "compact" : ""}`}>
      <Link href={`/product/${product.slug}`} className="product-image-wrap">
        <img src={product.image} alt={`${product.name} ${product.category} rainwear`} />
        <span className="product-hover">View details <ArrowUpRight size={15} /></span>
      </Link>
      <div className="product-card-meta">
        <div>
          <span className="product-category">{product.category} / {product.tags[1]}</span>
          <h3>{product.name}</h3>
        </div>
        <Link className="product-plus" href={`/product/${product.slug}`} aria-label={`View ${product.name} details`}><ArrowUpRight size={17} /></Link>
      </div>
      {!compact && <p>{product.description}</p>}
      <div className="product-card-actions"><Link href={`/product/${product.slug}`}>View details <ArrowUpRight size={13} /></Link><a href={`mailto:${contact.email}?subject=Enquiry about ${product.name}`}>Enquire now <ArrowUpRight size={13} /></a></div>
    </article>
  );
}

export function CategoryFeature({ item, index }: { item: (typeof categories)[number]; index: number }) {
  return (
    <Link href={`/products/${item.slug}`} className={`category-feature category-${item.accent} ${index % 2 ? "reverse" : ""}`}>
      <div className="category-feature-image"><img src={item.image} alt={`${item.key} rainwear collection`} /></div>
      <div className="category-feature-copy">
        <span className="eyebrow">{item.kicker}</span>
        <h3>{item.title.split("\n").map((line) => <span key={line}>{line}</span>)}</h3>
        <p>{item.description}</p>
        <span className="arrow-link">Explore {item.key}<ArrowUpRight size={16} /></span>
      </div>
    </Link>
  );
}

export function TrustStrip() {
  const items = [
    { icon: ShieldCheck, title: "Best quality", copy: "Durable and strong" },
    { icon: Sparkles, title: "Innovative", copy: "Design and craftsmanship" },
    { icon: Truck, title: "All-India reach", copy: "Prompt and reliable supply" },
  ];
  return <div className="trust-strip"><div className="site-shell trust-grid">{items.map(({ icon: Icon, title, copy }) => <div className="trust-item" key={title}><Icon size={20} strokeWidth={1.4} /><div><strong>{title}</strong><span>{copy}</span></div></div>)}</div></div>;
}

export function CompanyIntro({ home = false }: { home?: boolean }) {
  return (
    <section className={`company-intro ${home ? "home-intro" : ""}`} id={home ? "company" : undefined}>
      <div className="site-shell company-grid">
        <div className="company-image-frame"><img src={siteImages.gents} alt="Prince Rainwear rainwear collection" /><span className="image-stamp">EST. 2005<br />MUMBAI, INDIA</span></div>
        <div className="company-copy">
          <SectionIntro eyebrow="02 / The company" title="Protection meets experience." copy="Prince Rainwear Pvt. Ltd. was incorporated in 2005 as a private limited company. The company manufactures, wholesales and supplies rainwear for gents, ladies, kids and more." />
          <p className="body-copy">All products are manufactured using high-quality raw material procured from reliable and authorised vendors of the industry. A dexterous team and world-class infrastructural set-up support the company's production operations.</p>
          <ArrowLink href="/about">Read the company story</ArrowLink>
          <div className="fact-row">{companyFacts.map((fact) => <div key={fact.value}><strong>{fact.value}</strong><span>{fact.label}</span></div>)}</div>
        </div>
      </div>
    </section>
  );
}

export function ProductRail({ category }: { category?: Category }) {
  const visible = category ? products.filter((product) => product.category === category) : products.slice(0, 7);
  return <div className="product-rail">{visible.map((product) => <ProductCard key={product.slug} product={product} />)}</div>;
}

export function EnquiryBand() {
  return (
    <section className="enquiry-band">
      <div className="site-shell enquiry-inner">
        <div><span className="eyebrow">For distributors, wholesalers & retailers</span><h2>Bring dependable<br /><em>rainwear</em> to your market.</h2></div>
        <div className="enquiry-action"><p>Talk to the Prince Rainwear team about range, supply and business enquiries.</p><a className="button button-light" href="mailto:sales@princerainwear.com?subject=Prince Rainwear business enquiry">Make an enquiry <ArrowUpRight size={16} /></a></div>
      </div>
    </section>
  );
}

export function GalleryMosaic() {
  const [selected, setSelected] = useState<{ image: string; label: string } | null>(null);
  useEffect(() => {
    if (!selected) return;
    const handleKeyDown = (event: KeyboardEvent) => { if (event.key === "Escape") setSelected(null); };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [selected]);
  const items = [
    { image: siteImages.heroAlt, label: "Seasonal campaign", large: true },
    { image: siteImages.girls, label: "Girls rainwear" },
    { image: siteImages.quality, label: "Quality control" },
    { image: siteImages.ladiesRaincoat, label: "Ladies collection" },
    { image: siteImages.gentsRaincoat, label: "Gents collection" },
  ];
  return <>
    <div className="gallery-mosaic">{items.map((item) => <button type="button" className={`gallery-tile ${item.large ? "large" : ""}`} key={item.label} onClick={() => setSelected(item)} aria-label={`Zoom ${item.label}`}><img src={item.image} alt={item.label} /><span>{item.label}</span></button>)}</div>
    {selected && <div className="gallery-lightbox" role="dialog" aria-modal="true" aria-label={`${selected.label} image`} onClick={() => setSelected(null)}><div className="lightbox-content" tabIndex={-1} onClick={(event) => event.stopPropagation()}><button type="button" className="lightbox-close" onClick={() => setSelected(null)} aria-label="Close image viewer"><X size={22} /></button><img src={selected.image} alt={selected.label} /><span>{selected.label} / press Escape or click outside to close</span></div></div>}
  </>;
}

export function QualityCallout() {
  return (
    <section className="quality-callout">
      <div className="site-shell quality-grid">
        <div className="quality-art"><img src={siteImages.quality} alt="Quality control at Prince Rainwear" /><div className="quality-quote"><Quote size={20} /><p>Quality is not a finish line. It is built into every layer.</p></div></div>
        <div className="quality-copy"><SectionIntro eyebrow="06 / Quality & craft" title="Built for the weather. Considered for the wearer." copy="From raw material procurement to product finishing, Prince Rainwear keeps quality and reliable performance at the centre of its range." /><div className="check-list"><p><Check size={16} />High-quality raw material from reliable vendors</p><p><Check size={16} />Product development with a practical eye</p><p><Check size={16} />Quality checking across the production process</p></div><ArrowLink href="/quality">See our quality approach</ArrowLink></div>
      </div>
    </section>
  );
}
