import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { ArrowUpRight, ChevronDown, Menu, X } from "lucide-react";
import { contact, siteImages } from "@/data/site";

const primaryLinks = [
  { label: "About Us", href: "/about" },
  { label: "Manufacturing", href: "/manufacturing" },
  { label: "Quality", href: "/quality" },
  { label: "Gallery", href: "/gallery" },
  { label: "Contact Us", href: "/contact" },
];

const productLinks = [
  { label: "Girls", href: "/products/girls" },
  { label: "Boys", href: "/products/boys" },
  { label: "Gents", href: "/products/gents" },
  { label: "Ladies", href: "/products/ladies" },
  { label: "All Products", href: "/products" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [productsOpen, setProductsOpen] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    setOpen(false);
    setProductsOpen(false);
  }, [location]);

  useEffect(() => {
    if (!open) return;
    const handleKeyDown = (event: KeyboardEvent) => { if (event.key === "Escape") setOpen(false); };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [open]);

  return (
    <>
      <div className="topline">
        <div className="site-shell topline-inner">
          <span>PRINCE RAINWEAR PVT. LTD. / MUMBAI, INDIA</span>
          <a href={`mailto:${contact.email}`}>{contact.email}</a>
        </div>
      </div>
      <header className="site-header">
        <div className="site-shell nav-inner">
          <Link href="/" className="brand-lockup" aria-label="Prince Rainwear home">
            <img src={siteImages.logo} alt="Prince Rainwear" />
          </Link>

          <nav className={`desktop-nav ${open ? "is-open" : ""}`} aria-label="Primary navigation">
            <Link href="/" className={location === "/" ? "active" : ""}>Home</Link>
            <div className="nav-dropdown">
              <button
                type="button"
                className={location.startsWith("/products") ? "active" : ""}
                aria-expanded={productsOpen}
                onClick={() => setProductsOpen((value) => !value)}
              >
                Products <ChevronDown size={14} strokeWidth={1.5} />
              </button>
              <div className={`dropdown-panel ${productsOpen ? "visible" : ""}`}>
                <span className="dropdown-kicker">Browse the range</span>
                {productLinks.map((item) => (
                  <Link key={item.href} href={item.href}>{item.label}<ArrowUpRight size={14} /></Link>
                ))}
              </div>
            </div>
            {primaryLinks.map((item) => (
              <Link key={item.href} href={item.href} className={location === item.href ? "active" : ""}>{item.label}</Link>
            ))}
          </nav>

          <div className="nav-actions">
            <a className="nav-enquire" href="mailto:sales@princerainwear.com?subject=Business enquiry">Enquire <ArrowUpRight size={15} /></a>
            <button className="mobile-toggle" type="button" aria-label={open ? "Close navigation" : "Open navigation"} aria-expanded={open} aria-controls="mobile-navigation" onClick={() => setOpen((value) => !value)}>
              {open ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
        {open && (
          <div className="mobile-menu" id="mobile-navigation" role="navigation" aria-label="Mobile navigation">
            <Link href="/">Home</Link>
            <span className="mobile-menu-label">Products</span>
            {productLinks.map((item) => <Link key={item.href} href={item.href} className="nested">{item.label}</Link>)}
            {primaryLinks.map((item) => <Link key={item.href} href={item.href}>{item.label}</Link>)}
            <a className="mobile-menu-contact" href={`tel:${contact.mobile.replace(/\s|–/g, "")}`}>Call {contact.mobile}</a>
          </div>
        )}
      </header>
    </>
  );
}

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="site-shell footer-grid">
        <div className="footer-brand">
          <img src={siteImages.logo} alt="Prince Rainwear" />
          <p>Rainwear made for the days that test it. Manufacturing, wholesaling and supplying protection since 2005.</p>
          <a className="footer-arrow-link" href="mailto:sales@princerainwear.com">Start a conversation <ArrowUpRight size={15} /></a>
        </div>
        <div className="footer-column">
          <span className="footer-label">Explore</span>
          <Link href="/about">About Us</Link>
          <Link href="/products">All Products</Link>
          <Link href="/manufacturing">Manufacturing</Link>
          <Link href="/quality">Quality</Link>
        </div>
        <div className="footer-column">
          <span className="footer-label">Connect</span>
          <Link href="/gallery">Gallery</Link>
          <Link href="/contact">Contact Us</Link>
          <a href={`tel:${contact.mobile.replace(/\s|–/g, "")}`}>{contact.mobile}</a>
          <a href={`mailto:${contact.email}`}>{contact.email}</a>
        </div>
        <div className="footer-column footer-address">
          <span className="footer-label">Head Office</span>
          <p>{contact.address}</p>
        </div>
      </div>
      <div className="site-shell footer-bottom">
        <span>© {new Date().getFullYear()} Prince Rainwear Pvt. Ltd.</span>
        <span>Official company and product information preserved from the existing website.</span>
      </div>
    </footer>
  );
}

export function PageFrame({ children }: { children: React.ReactNode }) {
  return <div className="site-page"><SiteHeader />{children}<SiteFooter /></div>;
}

export function SectionIntro({ eyebrow, title, copy, action }: { eyebrow: string; title: string; copy?: string; action?: React.ReactNode }) {
  return (
    <div className="section-intro">
      <span className="eyebrow">{eyebrow}</span>
      <h2>{title}</h2>
      {copy && <p>{copy}</p>}
      {action}
    </div>
  );
}

export function ArrowLink({ href, children, light = false }: { href: string; children: React.ReactNode; light?: boolean }) {
  return <Link href={href} className={`arrow-link ${light ? "light" : ""}`}>{children}<ArrowUpRight size={16} /></Link>;
}
