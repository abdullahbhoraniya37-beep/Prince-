import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import { AboutPage, CategoryPage, ContactPage, GalleryPage, ManufacturingPage, ProductDetail, ProductsPage, QualityPage } from "./pages/SitePages";
import type { Category } from "./data/site";
import { siteImages } from "./data/site";
import { useEffect } from "react";

function Meta({ title, description }: { title: string; description: string }) {
  useEffect(() => {
    document.title = title;
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement("meta");
      meta.setAttribute("name", "description");
      document.head.appendChild(meta);
    }
    meta.setAttribute("content", description);
    const canonicalUrl = `https://princerainwear.com${window.location.pathname}`;
    let canonical = document.querySelector('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement("link");
      canonical.setAttribute("rel", "canonical");
      document.head.appendChild(canonical);
    }
    canonical.setAttribute("href", canonicalUrl);
    const setProperty = (property: string, content: string) => {
      let tag = document.querySelector(`meta[property="${property}"]`);
      if (!tag) {
        tag = document.createElement("meta");
        tag.setAttribute("property", property);
        document.head.appendChild(tag);
      }
      tag.setAttribute("content", content);
    };
    setProperty("og:title", title);
    setProperty("og:description", description);
    setProperty("og:type", "website");
    setProperty("og:url", canonicalUrl);
    setProperty("og:image", siteImages.hero);
  }, [title, description]);
  return null;
}

function RouteShell({ children, title, description }: { children: React.ReactNode; title: string; description: string }) {
  return <><Meta title={title} description={description} />{children}</>;
}

function Router() {
  return (
    <Switch>
      <Route path="/"><RouteShell title="Prince Rainwear — Ready for Every Storm" description="Prince Rainwear Pvt. Ltd. manufactures, wholesales and supplies rainwear for gents, ladies, kids and more from Mumbai, India."><Home /></RouteShell></Route>
      <Route path="/about"><RouteShell title="About Prince Rainwear — Experience in Every Layer" description="Learn about Prince Rainwear Pvt. Ltd., incorporated in 2005 and engaged in manufacturing, wholesaling and supplying rainwear."><AboutPage /></RouteShell></Route>
      <Route path="/products"><RouteShell title="Rainwear Catalogue — Prince Rainwear" description="Explore featured girls, boys, gents and ladies rainwear products from Prince Rainwear."><ProductsPage /></RouteShell></Route>
      <Route path="/products/girls"><RouteShell title="Girls Rainwear — Prince Rainwear" description="Explore girls raincoats and kids rainwear from Prince Rainwear."><CategoryPage category="Girls" /></RouteShell></Route>
      <Route path="/products/boys"><RouteShell title="Boys Rainwear — Prince Rainwear" description="Explore boys raincoats and kids rainwear from Prince Rainwear."><CategoryPage category="Boys" /></RouteShell></Route>
      <Route path="/products/gents"><RouteShell title="Gents Rainwear — Prince Rainwear" description="Explore gents raincoats, overcoats and jackets from Prince Rainwear."><CategoryPage category="Gents" /></RouteShell></Route>
      <Route path="/products/ladies"><RouteShell title="Ladies Rainwear — Prince Rainwear" description="Explore ladies raincoats and overcoat styles from Prince Rainwear."><CategoryPage category="Ladies" /></RouteShell></Route>
      <Route path="/product/:slug"><RouteShell title="Product detail — Prince Rainwear" description="Explore a featured Prince Rainwear product style and enquire with the company team."><ProductDetail /></RouteShell></Route>
      <Route path="/manufacturing"><RouteShell title="Manufacturing — Prince Rainwear" description="Discover the production, material and supply approach behind Prince Rainwear."><ManufacturingPage /></RouteShell></Route>
      <Route path="/quality"><RouteShell title="Quality & Craft — Prince Rainwear" description="Discover the quality approach behind Prince Rainwear's rainwear range."><QualityPage /></RouteShell></Route>
      <Route path="/gallery"><RouteShell title="Gallery — Prince Rainwear" description="A visual look at Prince Rainwear products, categories and quality story."><GalleryPage /></RouteShell></Route>
      <Route path="/contact"><RouteShell title="Contact Prince Rainwear" description="Contact Prince Rainwear for product, wholesale, retail and distribution enquiries."><ContactPage /></RouteShell></Route>
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster /><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>;
}

export default App;
