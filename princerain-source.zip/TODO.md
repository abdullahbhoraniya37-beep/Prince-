# Prince Rainwear Website ToDo

## Global navigation and information architecture
- [x] Build sticky, accessible global navigation with Home, About Us, Products, Manufacturing, Quality, Gallery and Contact Us.
- [x] Add a responsive mobile menu and a Products dropdown for Girls, Boys, Gents, Ladies and All Products.
- [x] Keep the experience catalogue/corporate-oriented with no prices, carts or ecommerce account UI.

## Homepage and storytelling
- [x] Create a cinematic hero featuring “READY FOR EVERY STORM.”, the supporting copy “Quality rainwear crafted for protection, comfort and confidence.”, and CTAs “EXPLORE OUR PRODUCTS” and “DISCOVER OUR COMPANY”.
- [x] Present the company introduction, incorporation in 2005, rainwear manufacturing/wholesale/supply business, key strengths and business-enquiry prompts.
- [x] Add editorial product category sections for Girls, Boys, Gents and Ladies.
- [x] Add featured product showcase with verified names including Anmol, Classic, Kajal O.C., Marshal O.C., Mary, Rider and Star, with category, description, View Details and Enquire actions.
- [x] Add manufacturing/infrastructure, quality/craftsmanship, gallery and contact/footer sections.

## Catalogue routes and page content
- [x] Add dedicated routes for About Us, Girls, Boys, Gents, Ladies and All Products.
- [x] Add product detail routes for the verified featured products where sufficient information is available.
- [x] Add dedicated Manufacturing, Quality, Gallery and Contact routes.
- [x] Preserve verified contact details: +91 – 22-26788486 / 9167535403, sales@princerainwear.com, and 8, K.M.C. Compound, Near Metro Palace Hotel, Behram Baug Road, Jogeshwari (West), Mumbai – 400102, India.

## Design and implementation quality
- [x] Apply the approved premium corporate editorial + modern industrial luxury design system with deep navy, steel blue, warm off-white, white, muted silver and charcoal.
- [x] Use semantic structure, keyboard-friendly interactions, restrained motion, strong metadata and responsive layouts.
- [x] Use original or properly licensed visuals and clearly label illustrative imagery where it is not authentic company photography.
- [x] Add and maintain `public/manus-routes.json` for all page routes.
- [x] Set project logo metadata and verify the preview build, responsive layout and type diagnostics.

## Enquiry, gallery and SEO polish
- [x] Add gallery lightbox, image zoom, smooth navigation and meaningful visual labels.
- [x] Add a client-side validated enquiry form with Name, Company Name, Phone, Email, City, Business Type, Product Interest and Message, plus a clearly labelled demo submission confirmation that does not claim delivery.
- [x] Include verified head office and factory details, call and email actions, and a map link.
- [x] Add canonical URLs, Open Graph metadata, Organization structured data, sitemap.xml and robots.txt without fake review/rating markup.
