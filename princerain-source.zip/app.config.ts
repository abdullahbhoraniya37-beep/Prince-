export default {
  logoUrl: "https://princerainwear.com/wp-content/uploads/2021/03/Prince-Logo-1.png",
};
